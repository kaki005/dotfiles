return {
	text = "SF Pro", -- Used for text
	-- test = "JetBrainsMono Nerd Font",
	numbers = "SF Mono", -- Used for numbers

	-- Unified font style map
	style_map = {
		["Regular"] = "Regular",
		["Semibold"] = "Semibold",
		["Bold"] = "Bold",
		["Heavy"] = "Heavy",
		["Black"] = "Black",
	},
}
