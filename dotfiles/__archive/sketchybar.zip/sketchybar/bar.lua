local colors = require("colors")

-- Equivalent to the --bar domain
sbar.bar({
	-- topmost = "window",
	height = 44,
	margin = 0,
	color = 0x0000000,
	y_offset = 0,
	padding_right = 8,
	padding_left = 8,
})
